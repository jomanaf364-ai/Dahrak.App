import 'package:flutter/material.dart';

void main() => runApp(const DaharkApp());

const Color ink = Color(0xFF29234F);
const Color purple = Color(0xFF6254B8);
const Color blue = Color(0xFF6C91E8);
const Color mint = Color(0xFFDDF3EA);
const Color cream = Color(0xFFFFF8EC);
const Color softLilac = Color(0xFFF0EDFF);

class DaharkApp extends StatelessWidget {
  const DaharkApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ضهرك',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Roboto',
        scaffoldBackgroundColor: cream,
        colorScheme: ColorScheme.fromSeed(seedColor: purple),
        appBarTheme: const AppBarTheme(
          backgroundColor: cream,
          foregroundColor: ink,
          centerTitle: true,
          elevation: 0,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
          contentPadding: const EdgeInsets.all(16),
        ),
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selected = 0;
  final pages = const [
    HomePage(),
    ReportPage(),
    LearnPage(),
    SupportPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(child: pages[selected]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: selected,
          onDestinationSelected: (i) => setState(() => selected = i),
          backgroundColor: Colors.white,
          indicatorColor: softLilac,
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.shield_outlined), selectedIcon: Icon(Icons.shield), label: 'إبلاغ'),
            NavigationDestination(icon: Icon(Icons.lightbulb_outline), selectedIcon: Icon(Icons.lightbulb), label: 'اتعلم'),
            NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'مساعدة'),
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: softLilac, borderRadius: BorderRadius.circular(18)),
              child: const Icon(Icons.shield_moon_outlined, color: purple, size: 32),
            ),
            const SizedBox(width: 12),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('ضهرك', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold, color: ink)),
                Text('وطن بلا تنمر', style: TextStyle(color: purple, fontWeight: FontWeight.w600)),
              ],
            ),
            const Spacer(),
            const Icon(Icons.wb_sunny_outlined, color: blue, size: 28),
          ],
        ),
        const SizedBox(height: 24),
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [purple, blue], begin: Alignment.topRight, end: Alignment.bottomLeft),
            borderRadius: BorderRadius.circular(26),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('مش لازم تواجه لوحدك', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text('كل شخص يستحق مكانًا آمنًا، وكلمة طيبة، ومعاملة باحترام.', style: TextStyle(color: Colors.white, height: 1.6)),
              SizedBox(height: 16),
              Icon(Icons.diversity_3, color: Colors.white, size: 48),
            ],
          ),
        ),
        const SizedBox(height: 22),
        const Text('تقدر تبدأ من هنا', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: ink)),
        const SizedBox(height: 12),
        _HomeTile(icon: Icons.campaign_outlined, title: 'عايز أبلغ عن موقف', subtitle: 'سجّل تفاصيل عامة واطلب مساعدة شخص موثوق', color: softLilac, onTap: () => _go(context, 1)),
        _HomeTile(icon: Icons.quiz_outlined, title: 'اختبر معلوماتك', subtitle: 'تعلّم تميّز التنمر وتختار التصرف الآمن', color: mint, onTap: () => _go(context, 2)),
        _HomeTile(icon: Icons.favorite_outline, title: 'محتاج دعم؟', subtitle: 'خطوات بسيطة ومصادر مساعدة', color: const Color(0xFFFFE9E2), onTap: () => _go(context, 3)),
        const SizedBox(height: 12),
        const QuoteCard(),
        const SizedBox(height: 12),
        const Text('تنبيه: التطبيق نموذج توعوي. البلاغات هنا لا تُرسل تلقائيًا لأي جهة.', style: TextStyle(color: Colors.black54, fontSize: 12, height: 1.5)),
      ],
    );
  }

  void _go(BuildContext context, int index) {
    final state = context.findAncestorStateOfType<_MainShellState>();
    state?.setState(() => state.selected = index);
  }
}

class _HomeTile extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  final Color color;
  final VoidCallback onTap;
  const _HomeTile({required this.icon, required this.title, required this.subtitle, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: ListTile(
        onTap: onTap,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
        leading: CircleAvatar(backgroundColor: color, child: Icon(icon, color: ink)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, color: ink)),
        subtitle: Text(subtitle, style: const TextStyle(height: 1.4)),
        trailing: const Icon(Icons.arrow_back_ios_new, size: 16, color: purple),
      ),
    );
  }
}

class QuoteCard extends StatelessWidget {
  const QuoteCard({super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: mint, borderRadius: BorderRadius.circular(20)),
      child: const Row(
        children: [
          Icon(Icons.format_quote, color: purple, size: 32),
          SizedBox(width: 10),
          Expanded(child: Text('اختلافنا مش سبب للأذى؛ الاحترام حق لكل إنسان.', style: TextStyle(color: ink, fontWeight: FontWeight.w600, height: 1.5))),
        ],
      ),
    );
  }
}

class ReportPage extends StatefulWidget {
  const ReportPage({super.key});
  @override
  State<ReportPage> createState() => _ReportPageState();
}

class _ReportPageState extends State<ReportPage> {
  String kind = 'لفظي';
  String place = 'المدرسة';
  final details = TextEditingController();
  bool wantsAdult = true;

  @override
  void dispose() { details.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const PageHeading(title: 'الإبلاغ عن موقف', subtitle: 'اكتب معلومات عامة تساعدك ترتّب أفكارك وتطلب دعمًا مناسبًا.'),
        const SafetyNote(text: 'لو في خطر مباشر أو خايف/ة على سلامتك، ابتعد/ي لمكان آمن واطلب/ي مساعدة شخص بالغ موثوق فورًا.'),
        const SizedBox(height: 18),
        const Text('نوع الموقف', style: TextStyle(fontWeight: FontWeight.bold, color: ink)),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: kind,
          items: ['لفظي', 'استبعاد أو مضايقة', 'إلكتروني', 'جسدي أو تهديد', 'مش متأكد/ة'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
          onChanged: (v) => setState(() => kind = v ?? kind),
        ),
        const SizedBox(height: 16),
        const Text('حصل فين؟', style: TextStyle(fontWeight: FontWeight.bold, color: ink)),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: place,
          items: ['المدرسة', 'الإنترنت', 'مكان عام', 'مكان آخر'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
          onChanged: (v) => setState(() => place = v ?? place),
        ),
        const SizedBox(height: 16),
        const Text('وصف مختصر (من غير أسماء أو بيانات شخصية)', style: TextStyle(fontWeight: FontWeight.bold, color: ink)),
        const SizedBox(height: 8),
        TextField(controller: details, maxLines: 5, maxLength: 500, decoration: const InputDecoration(hintText: 'اكتب/ي اللي حصل بشكل عام...')),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          value: wantsAdult,
          activeColor: purple,
          onChanged: (v) => setState(() => wantsAdult = v),
          title: const Text('عايز/ة أتكلم مع شخص بالغ موثوق'),
        ),
        const SizedBox(height: 12),
        FilledButton.icon(
          style: FilledButton.styleFrom(backgroundColor: purple, padding: const EdgeInsets.all(16)),
          onPressed: () {
            if (details.text.trim().isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اكتب وصفًا عامًا للموقف الأول.')));
              return;
            }
            showDialog(context: context, builder: (_) => AlertDialog(
              title: const Text('تم تجهيز ملخصك'),
              content: Text('نوع الموقف: $kind\nالمكان: $place\n\n${wantsAdult ? 'الخطوة المقترحة: شارك/ي الملخص مع شخص بالغ موثوق.' : 'فكّر/ي في شخص بالغ آمن يمكنك الرجوع إليه.'}\n\nهذا النموذج لا يحفظ البلاغ ولا يرسله.'),
              actions: [TextButton(onPressed: () { Navigator.pop(context); details.clear(); }, child: const Text('حسنًا'))],
            ));
          },
          icon: const Icon(Icons.check_circle_outline),
          label: const Text('جهّز ملخص الموقف'),
        ),
        const SizedBox(height: 12),
        const Text('لا تكتب أسماء أشخاص أو أرقام هواتف أو عناوين أو كلمات مرور.', style: TextStyle(color: Colors.black54, fontSize: 12)),
      ],
    );
  }
}

class LearnPage extends StatelessWidget {
  const LearnPage({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const PageHeading(title: 'اتعلّم وشارك', subtitle: 'معلومات ومواقف تساعدنا نبني بيئة أكثر احترامًا.'),
        const QuoteCard(),
        const SizedBox(height: 18),
        const Text('اختبر نفسك', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: ink)),
        const SizedBox(height: 10),
        const QuizCard(question: 'لو شفت زميل بيتعرض للسخرية، إيه التصرف الأفضل؟', options: ['أشارك في الضحك', 'أطلب المساعدة وأسانده بأمان', 'أتفرج وأنشر الموقف'], correct: 1, explanation: 'المساندة الآمنة وطلب مساعدة شخص بالغ موثوق أفضل من المشاركة أو النشر.'),
        const QuizCard(question: 'هل الاختلاف في الشكل أو اللهجة مبرر للسخرية؟', options: ['أيوه', 'لأ، الاحترام حق للجميع', 'حسب الشخص'], correct: 1, explanation: 'الاختلاف مش مبرر للإيذاء أو التقليل من أي شخص.'),
        const QuizCard(question: 'لو حد بعتلك رسالة مؤذية أونلاين، تعمل إيه؟', options: ['أرد بإهانة', 'أحتفظ بالدليل وأطلب مساعدة بالغ موثوق', 'أعيد نشرها'], correct: 1, explanation: 'ما تدخلش في تصعيد. اطلب مساعدة شخص بالغ موثوق واستخدم أدوات الحظر والإبلاغ المناسبة.'),
        const SizedBox(height: 18),
        const Text('بدّل مكانك', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: ink)),
        const ScenarioCard(),
      ],
    );
  }
}

class QuizCard extends StatefulWidget {
  final String question, explanation;
  final List<String> options;
  final int correct;
  const QuizCard({super.key, required this.question, required this.options, required this.correct, required this.explanation});
  @override
  State<QuizCard> createState() => _QuizCardState();
}
class _QuizCardState extends State<QuizCard> {
  int? answer;
  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(widget.question, style: const TextStyle(fontWeight: FontWeight.bold, color: ink, height: 1.5)),
          const SizedBox(height: 10),
          ...List.generate(widget.options.length, (i) => RadioListTile<int>(
            contentPadding: EdgeInsets.zero,
            dense: true,
            activeColor: purple,
            value: i,
            groupValue: answer,
            onChanged: (v) => setState(() => answer = v),
            title: Text(widget.options[i]),
          )),
          if (answer != null)
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: answer == widget.correct ? mint : const Color(0xFFFFE9E2), borderRadius: BorderRadius.circular(12)),
              child: Text('${answer == widget.correct ? 'إجابة صحيحة.' : 'حاول تاني.'} ${widget.explanation}', style: const TextStyle(height: 1.5)),
            ),
        ]),
      ),
    );
  }
}

class ScenarioCard extends StatefulWidget {
  const ScenarioCard({super.key});
  @override
  State<ScenarioCard> createState() => _ScenarioCardState();
}
class _ScenarioCardState extends State<ScenarioCard> {
  bool? chosen;
  @override
  Widget build(BuildContext context) {
    return Card(
      color: softLilac,
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('طالب جديد قاعد لوحده ومحدش بيكلمه. إيه اللي ممكن تعمله؟', style: TextStyle(fontWeight: FontWeight.bold, color: ink, height: 1.5)),
          const SizedBox(height: 12),
          FilledButton.tonal(onPressed: () => setState(() => chosen = true), child: const Text('أرحب بيه وأدعوه يشارك لو حابب')),
          OutlinedButton(onPressed: () => setState(() => chosen = false), child: const Text('أتجاهله')),
          if (chosen != null) Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(chosen! ? 'اختيار لطيف. المبادرة البسيطة ممكن تفرق.' : 'جرّب تفكر في أثر التجاهل، واختار تصرفًا أكثر دعمًا.', style: const TextStyle(fontWeight: FontWeight.w600)),
          ),
        ]),
      ),
    );
  }
}

class SupportPage extends StatelessWidget {
  const SupportPage({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: const [
        PageHeading(title: 'إنت تستحق الأمان', subtitle: 'طلب المساعدة تصرف شجاع، ومش لازم تتعامل مع الموقف لوحدك.'),
        SupportTile(icon: Icons.person_outline, title: 'اختار شخصًا بالغًا موثوقًا', body: 'ممكن يكون أحد والديك، قريب تثق فيه، مدرس/ة، أو الأخصائي الاجتماعي بالمدرسة.'),
        SupportTile(icon: Icons.chat_bubble_outline, title: 'ابدأ بجملة بسيطة', body: '«في موقف مضايقني ومحتاج أتكلم معاك. ممكن تسمعني وتساعدني؟»'),
        SupportTile(icon: Icons.event_note_outlined, title: 'اكتب اللي حصل', body: 'دوّن الوقت والمكان وما حدث بشكل عام، واحتفظ بأي دليل رقمي بأمان. لا تنشره ولا ترسله للآخرين.'),
        SupportTile(icon: Icons.health_and_safety_outlined, title: 'لو في خطر مباشر', body: 'ابتعد لمكان آمن واطلب مساعدة شخص بالغ موثوق أو خدمات الطوارئ المحلية.'),
        SafetyNote(text: 'التطبيق ليس خدمة طوارئ أو علاجًا نفسيًا، ولا يراقب البلاغات. تحدث مع شخص بالغ موثوق في الواقع.'),
      ],
    );
  }
}

class SupportTile extends StatelessWidget {
  final IconData icon;
  final String title, body;
  const SupportTile({super.key, required this.icon, required this.title, required this.body});
  @override
  Widget build(BuildContext context) => Card(
    color: Colors.white,
    elevation: 0,
    margin: const EdgeInsets.only(bottom: 12),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    child: ListTile(
      contentPadding: const EdgeInsets.all(14),
      leading: CircleAvatar(backgroundColor: softLilac, child: Icon(icon, color: purple)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, color: ink)),
      subtitle: Padding(padding: const EdgeInsets.only(top: 6), child: Text(body, style: const TextStyle(height: 1.5))),
    ),
  );
}

class PageHeading extends StatelessWidget {
  final String title, subtitle;
  const PageHeading({super.key, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 18),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold, color: ink)),
      const SizedBox(height: 6),
      Text(subtitle, style: const TextStyle(color: Colors.black54, height: 1.6)),
    ]),
  );
}

class SafetyNote extends StatelessWidget {
  final String text;
  const SafetyNote({super.key, required this.text});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: const Color(0xFFFFE9E2), borderRadius: BorderRadius.circular(16)),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Icon(Icons.info_outline, color: Color(0xFF9B4D36)),
      const SizedBox(width: 10),
      Expanded(child: Text(text, style: const TextStyle(height: 1.5, color: ink))),
    ]),
  );
}
